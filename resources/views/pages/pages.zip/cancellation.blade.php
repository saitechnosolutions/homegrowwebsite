@extends('layouts.default')
@section('main-content')
    <section class="privacy_section">
        <div class="container">
            <h5 class="Conditions">Cancellation</h5>
               <!--<h5 class="Conditions">Cancellation & Refund Policy</h5>-->
            <div class="row">
                <div class="col-lg-12 col-12">
                    <!--<p class="kad">Terms Of Use | Legal | Refunds | Cancellations</p>-->

                    <!--<h5 class="billss">Order Booking and Financial Terms</h5>-->
                       <h5 class="billss">Cancellations</h5>
  
  <p>If you change your mind before you have received your order, we are able to accept cancellations at any time before the order has been ‘Processed’.</p>
  
  
  <p>For all customer service enquirers, please call or Whatsapp us at 7788996891.</p>

                </div>
            </div>
        </div>
    </section>
@endsection